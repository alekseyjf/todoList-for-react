export const GET_TASKS = 'GET_TASKS';
export const GET_SINGLE_TASK = 'GET_SINGLE_TASK';
export const SET_SINGLE_TASK = 'SET_SINGLE_TASK';

export const getTasks = tasks => ({
  type: GET_TASKS,
  tasks
});

export const getSingleTask = id => {
  console.log('GET_SINGLE_TASK', id);
  return {
    type: GET_SINGLE_TASK,
    id
  }
};
export const setSingleTask = singleTask => {
  // console.log('SET_SINGLE_TASK', singleTask);
  return {
    type: SET_SINGLE_TASK,
    singleTask
  }
};