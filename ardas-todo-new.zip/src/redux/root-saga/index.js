import { takeEvery, all, put } from 'redux-saga/effects'
import {GET_SINGLE_TASK, setSingleTask} from "../actions";
import json from '../../services/tasks';
const delay = (ms) => new Promise(res => setTimeout(res, ms))

function* getTask () {

  yield takeEvery(GET_SINGLE_TASK, function*(action){
    console.log(action);
    const [singleTask] = json.filter( task => task.id === +action.id )
    yield delay(1000);
    console.log('singleTask', singleTask);
    yield put(setSingleTask(singleTask))
  })
}


export default function* rootSaga() {
  yield all([
    getTask()
  ])
}
