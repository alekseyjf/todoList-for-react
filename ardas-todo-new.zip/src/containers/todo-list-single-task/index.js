import React, { useState, useEffect } from "react";
import {withRouter} from "react-router-dom";
import {connect} from "react-redux";
import {getSingleTask} from "../../redux/actions";

const SingleTask = (props) => {
  console.log(props);
  const { match: {params: {id} }, getSingleTask, singleTask: {name, description}, loaded } = props,
        [isEditable, setIsEditable] = useState(false);
  const  [label, editLabel] = useState(name);

  const load = !loaded ? <h2>ЗАГРУЗКА</h2> : <div>Данные загрузились</div>
  // const deskEdit = (e) => {
  //   editLabel(e.target.value)
  // };
  // const submitDesk = (e) => {
  //   e.preventDefault();
  // }
  // const deskEditable = isEditable ?
  //   (<p onClick={setIsEditable(!isEditable)}>{label}</p>)
  //   : (<form onSubmit={submitDesk}><input type="text" onChange={deskEdit} defaultValue={label}/></form>)
  //
  // console.log('labellabellabel', label);


  useEffect(() => {
    getSingleTask(id)
  }, []);

  return (
    <>
      <div>{name}</div>
      {load}
      <p>{label}</p>
      <p>{description}</p>
    </>
  )
};

const mapStateToProps = ({singleTask, loaded}) => ({ singleTask, loaded });
const mapDispatchToProps = {
  getSingleTask
};

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(SingleTask))