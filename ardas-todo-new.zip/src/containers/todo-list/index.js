import React, {useEffect} from "react";
import {connect} from "react-redux";
import {getTasks} from "../../redux/actions";
import TodoListItem from "../../components/todo-list-item";

import json from '../../services/tasks.json';

const STATUS_ACTIVE = 'active';

const TodoList = (props) => {
  const {tasks, getTasks} = props
  useEffect(()=>{
    getTasks(json)
  },[]);

  const todoList = tasks
  .filter(item => {
    return item.obj_status === STATUS_ACTIVE
  })
  .map(item => {
    const importantClass = item.is_high_priority ? 'important' : null
    return (
      <tr key={item.id} className={importantClass}>
        <TodoListItem item={item} />
      </tr>
    )
  })


  return (
    <div>
      <table>
        <thead>
        <tr>
          <th>Tags</th>
          <th>Name</th>
          <th>working hours</th>
          <th>estimated time to work</th>
          <th>time to work end</th>
        </tr>
        </thead>
        <tbody>{todoList}</tbody>
      </table>
    </div>
  )
}

const mapStateToProps = ({tasks}) => ({tasks})

const mapDispatchToProps = {
  getTasks
}

export default connect(mapStateToProps, mapDispatchToProps)(TodoList)