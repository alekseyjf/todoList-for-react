import React from 'react';
import TodoList from "../todo-list";
import SingleTask from "../../containers/todo-list-single-task";
import {Route, Switch} from "react-router-dom";
import './index.css';

const App = () => {
  return (
    <div>
      <Switch>
        <Route path="/" component={TodoList} exact />
        <Route path="/task/:id" component={SingleTask}/>
      </Switch>
    </div>
  )
}
export default App;